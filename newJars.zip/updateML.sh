unzip ords.war

zip -d ords.war WEB-INF/lib/oraml-core-230314.0248.jar

zip -d ords.war WEB-INF/lib/oraml-jetty-230314.0248.jar

cp oraml-core.jar WEB-INF/lib/oraml-core-230314.0248.jar

cp oraml-jetty.jar WEB-INF/lib/oraml-jetty-230314.0248.jar

zip ords.war WEB-INF/lib/oraml-core-230314.0248.jar

zip ords.war WEB-INF/lib/oraml-jetty-230314.0248.jar

