SELECT /* ^^script..sql Cursor Sharing List */
ROWNUM "#", v.* FROM (
SELECT /*+ NO_MERGE */
inst_id
, child_number
, reason
FROM gv$sql_shared_cursor
WHERE :shared_cursor = 'Y'
AND sql_id = '3zppxfr1zf4cs'
ORDER BY 1, 2) v;
