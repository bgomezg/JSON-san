SELECT /* ^^script..sql Cursor Sharing as per Reason */
CHR(10)||'<tr>'||CHR(10)||
'<td class="r">'||ROWNUM||'</td>'||CHR(10)||
'<td>'||v2.reason||'</td>'||CHR(10)||
'<td class="c">'||v2.inst_id||'</td>'||CHR(10)||
'<td class="r">'||v2.cursors||'</td>'||CHR(10)||
'</tr>'
FROM (
SELECT 'reason' reason, 0 inst_id, 0 cursors FROM DUAL WHERE 1 = 0
ORDER BY reason, inst_id ) v2;
