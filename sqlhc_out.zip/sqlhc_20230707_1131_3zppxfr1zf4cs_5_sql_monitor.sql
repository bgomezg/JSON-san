-- SQL Monitor Report for ^^sql_id.
VAR mon_exec_start VARCHAR2(14);
VAR mon_exec_id NUMBER;
VAR mon_sql_plan_hash_value NUMBER;
VAR mon_inst_id NUMBER;
VAR mon_report CLOB;
VAR mon_sql_id VARCHAR2(13);
EXEC :mon_sql_id := '3zppxfr1zf4cs';
SET ECHO OFF FEED OFF VER OFF SHOW OFF HEA OFF LIN 2000 NEWP NONE PAGES 0 LONG 2000000 LONGC 2000 SQLC MIX TAB ON TRIMS ON TI OFF TIMI OFF ARRAY 100 NUMF "" SQLP SQL> SUF sql BLO . RECSEP OFF APPI OFF AUTOT OFF;

