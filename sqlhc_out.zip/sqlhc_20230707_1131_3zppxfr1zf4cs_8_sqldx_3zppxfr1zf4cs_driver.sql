REM $Header: 1366133.1 sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_driver.sql 12.1.04 2013/11/11 carlos.sierra $
REM created by sqldx.sql
SET DEF ON;
SET DEF ^ TERM OFF ECHO OFF FEED OFF VER OFF SHOW OFF HEA OFF LIN 2000 NUM 20 NEWP NONE PAGES 0 LONG 2000000 LONGC 2000 SQLC MIX TAB ON TRIMS ON TI OFF TIMI OFF ARRAY 100 NUMF "" SQLP SQL> SUF sql BLO . RECSEP OFF APPI OFF AUTOT OFF SERVEROUT ON SIZE UNL;
ALTER SESSION SET nls_numeric_characters = ".,";
ALTER SESSION SET nls_date_format = 'YYYY-MM-DD/HH24:MI:SS';
ALTER SESSION SET nls_timestamp_format = 'YYYY-MM-DD/HH24:MI:SS.FF';
ALTER SESSION SET nls_timestamp_tz_format = 'YYYY-MM-DD/HH24:MI:SS.FF TZH:TZM';
ALTER SESSION SET nls_sort = 'BINARY';
ALTER SESSION SET nls_comp = 'BINARY';
CL BRE COL;
-- YYYY-MM-DD/HH24:MI:SS
COL time_stamp1 NEW_V time_stamp1 FOR A20;
/*********************************************************************************/
SET TERM ON;
PRO ###
PRO ### by sql_id
PRO ###
SET TERM OFF;
-- skip: DBA_ACCHK_EVENTS by sql_id. reason: COUNT(*) = 0
-- skip: DBA_ACCHK_EVENTS_SUMMARY by sql_id. reason: COUNT(*) = 0
-- skip: DBA_ADVISOR_SQLA_TABLES by sql_id. reason: COUNT(*) = 0
-- skip: DBA_ADVISOR_SQLA_WK_STMTS by sql_id. reason: COUNT(*) = 0
-- skip: DBA_ADVISOR_SQLPLANS by sql_id. reason: COUNT(*) = 0
-- skip: DBA_ADVISOR_SQLSTATS by sql_id. reason: COUNT(*) = 0
-- skip: DBA_HIST_ACTIVE_SESS_HISTORY by sql_id. reason: COUNT(*) = 0
-- skip: DBA_HIST_COLORED_SQL by sql_id. reason: COUNT(*) = 0
-- skip: DBA_HIST_SQLBIND by sql_id. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID DBA_HIST_SQLSTAT');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_HIST_SQLSTAT ^^time_stamp1.');
-- select: DBA_HIST_SQLSTAT by sql_id. count(*): 3
SET TERM ON;
PRO ^^time_stamp1. DBA_HIST_SQLSTAT;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_DBA_HIST_SQLSTAT.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_HIST_SQLSTAT WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID DBA_HIST_SQLTEXT');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_HIST_SQLTEXT ^^time_stamp1.');
-- select: DBA_HIST_SQLTEXT by sql_id. count(*): 2
SET TERM ON;
PRO ^^time_stamp1. DBA_HIST_SQLTEXT;
SET TERM OFF;
-- output_type: C
COL sql_text PRI;
COL sql_fulltext PRI;
BRE ON sql_text ON sql_fulltext;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_DBA_HIST_SQLTEXT.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_HIST_SQLTEXT WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_HIST_SQL_BIND_METADATA by sql_id. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID DBA_HIST_SQL_PLAN');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_HIST_SQL_PLAN ^^time_stamp1.');
-- select: DBA_HIST_SQL_PLAN by sql_id. count(*): 10
SET TERM ON;
PRO ^^time_stamp1. DBA_HIST_SQL_PLAN;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_DBA_HIST_SQL_PLAN.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_HIST_SQL_PLAN WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_RAT_CAPTURE_SCHEMA_INFO by sql_id. reason: COUNT(*) = 0
-- skip: DBA_SQLSET_BINDS by sql_id. reason: COUNT(*) = 0
-- skip: DBA_SQLSET_PLANS by sql_id. reason: COUNT(*) = 0
-- skip: DBA_SQLSET_STATEMENTS by sql_id. reason: COUNT(*) = 0
-- skip: DBA_SQL_TRANSLATIONS by sql_id. reason: COUNT(*) = 0
-- skip: DBA_STATEMENTS by sql_id. reason: COUNT(*) = 0
-- skip: DBA_WORKLOAD_CAPTURE_SQLTEXT by sql_id. reason: COUNT(*) = 0
-- skip: DBA_WORKLOAD_DIV_SUMMARY by sql_id. reason: COUNT(*) = 0
-- skip: DBA_WORKLOAD_LONG_SQLTEXT by sql_id. reason: COUNT(*) = 0
-- skip: DBA_WORKLOAD_REPLAY_DIVERGENCE by sql_id. reason: COUNT(*) = 0
-- skip: DBA_WORKLOAD_SQL_MAP by sql_id. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID GV_$ACTIVE_SESSION_HISTORY');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$ACTIVE_SESSION_HISTORY ^^time_stamp1.');
-- select: GV$ACTIVE_SESSION_HISTORY by sql_id. count(*): 3
SET TERM ON;
PRO ^^time_stamp1. GV$ACTIVE_SESSION_HISTORY;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_GVsACTIVE_SESSION_HISTORY.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$ACTIVE_SESSION_HISTORY WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID GV_$ALL_ACTIVE_SESSION_HISTORY');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$ALL_ACTIVE_SESSION_HISTORY ^^time_stamp1.');
-- select: GV$ALL_ACTIVE_SESSION_HISTORY by sql_id. count(*): 3
SET TERM ON;
PRO ^^time_stamp1. GV$ALL_ACTIVE_SESSION_HISTORY;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_GVsALL_ACTIVE_SESSION_HISTORY.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$ALL_ACTIVE_SESSION_HISTORY WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: GV$ALL_SQL_MONITOR by sql_id. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID GV_$ALL_SQL_PLAN');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$ALL_SQL_PLAN ^^time_stamp1.');
-- select: GV$ALL_SQL_PLAN by sql_id. count(*): 5
SET TERM ON;
PRO ^^time_stamp1. GV$ALL_SQL_PLAN;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_GVsALL_SQL_PLAN.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$ALL_SQL_PLAN WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: GV$ALL_SQL_PLAN_MONITOR by sql_id. reason: COUNT(*) = 0
-- skip: GV$AW_LONGOPS by sql_id. reason: COUNT(*) = 0
-- skip: GV$CELL_OFL_THREAD_HISTORY by sql_id. reason: COUNT(*) = 0
-- skip: GV$CELL_THREAD_HISTORY by sql_id. reason: COUNT(*) = 0
-- skip: GV$KEY_VECTOR by sql_id. reason: COUNT(*) = 0
-- skip: GV$MAPPED_SQL by sql_id. reason: COUNT(*) = 0
-- skip: GV$OPEN_CURSOR by sql_id. reason: COUNT(*) = 0
-- skip: GV$SESSION by sql_id. reason: COUNT(*) = 0
-- skip: GV$SESSION_LONGOPS by sql_id. reason: COUNT(*) = 0
-- skip: GV$SORT_USAGE by sql_id. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID GV_$SQL');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQL ^^time_stamp1.');
-- select: GV$SQL by sql_id. count(*): 1
SET TERM ON;
PRO ^^time_stamp1. GV$SQL;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_GVsSQL.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQL WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID GV_$SQLAREA');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQLAREA ^^time_stamp1.');
-- select: GV$SQLAREA by sql_id. count(*): 1
SET TERM ON;
PRO ^^time_stamp1. GV$SQLAREA;
SET TERM OFF;
-- output_type: C
COL sql_text PRI;
COL sql_fulltext PRI;
BRE ON sql_text ON sql_fulltext;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_GVsSQLAREA.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQLAREA WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID GV_$SQLAREA_PLAN_HASH');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQLAREA_PLAN_HASH ^^time_stamp1.');
-- select: GV$SQLAREA_PLAN_HASH by sql_id. count(*): 1
SET TERM ON;
PRO ^^time_stamp1. GV$SQLAREA_PLAN_HASH;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_GVsSQLAREA_PLAN_HASH.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQLAREA_PLAN_HASH WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID GV_$SQLSTATS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQLSTATS ^^time_stamp1.');
-- select: GV$SQLSTATS by sql_id. count(*): 1
SET TERM ON;
PRO ^^time_stamp1. GV$SQLSTATS;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_GVsSQLSTATS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQLSTATS WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID GV_$SQLSTATS_PLAN_HASH');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQLSTATS_PLAN_HASH ^^time_stamp1.');
-- select: GV$SQLSTATS_PLAN_HASH by sql_id. count(*): 1
SET TERM ON;
PRO ^^time_stamp1. GV$SQLSTATS_PLAN_HASH;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_GVsSQLSTATS_PLAN_HASH.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQLSTATS_PLAN_HASH WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID GV_$SQLTEXT');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQLTEXT ^^time_stamp1.');
-- select: GV$SQLTEXT by sql_id. count(*): 9
SET TERM ON;
PRO ^^time_stamp1. GV$SQLTEXT;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_GVsSQLTEXT.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQLTEXT WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID GV_$SQLTEXT_WITH_NEWLINES');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQLTEXT_WITH_NEWLINES ^^time_stamp1.');
-- select: GV$SQLTEXT_WITH_NEWLINES by sql_id. count(*): 9
SET TERM ON;
PRO ^^time_stamp1. GV$SQLTEXT_WITH_NEWLINES;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_GVsSQLTEXT_WITH_NEWLINES.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQLTEXT_WITH_NEWLINES WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: GV$SQL_BIND_CAPTURE by sql_id. reason: COUNT(*) = 0
-- skip: GV$SQL_CS_HISTOGRAM by sql_id. reason: COUNT(*) = 0
-- skip: GV$SQL_CS_SELECTIVITY by sql_id. reason: COUNT(*) = 0
-- skip: GV$SQL_CS_STATISTICS by sql_id. reason: COUNT(*) = 0
-- skip: GV$SQL_DIAG_REPOSITORY by sql_id. reason: COUNT(*) = 0
-- skip: GV$SQL_DIAG_REPOSITORY_REASON by sql_id. reason: COUNT(*) = 0
-- skip: GV$SQL_MONITOR by sql_id. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID GV_$SQL_OPTIMIZER_ENV');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQL_OPTIMIZER_ENV ^^time_stamp1.');
-- select: GV$SQL_OPTIMIZER_ENV by sql_id. count(*): 70
SET TERM ON;
PRO ^^time_stamp1. GV$SQL_OPTIMIZER_ENV;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_GVsSQL_OPTIMIZER_ENV.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQL_OPTIMIZER_ENV WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID GV_$SQL_PLAN');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQL_PLAN ^^time_stamp1.');
-- select: GV$SQL_PLAN by sql_id. count(*): 5
SET TERM ON;
PRO ^^time_stamp1. GV$SQL_PLAN;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_GVsSQL_PLAN.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQL_PLAN WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: GV$SQL_PLAN_MONITOR by sql_id. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID GV_$SQL_PLAN_STATISTICS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQL_PLAN_STATISTICS ^^time_stamp1.');
-- select: GV$SQL_PLAN_STATISTICS by sql_id. count(*): 4
SET TERM ON;
PRO ^^time_stamp1. GV$SQL_PLAN_STATISTICS;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_GVsSQL_PLAN_STATISTICS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQL_PLAN_STATISTICS WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID GV_$SQL_PLAN_STATISTICS_ALL');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQL_PLAN_STATISTICS_ALL ^^time_stamp1.');
-- select: GV$SQL_PLAN_STATISTICS_ALL by sql_id. count(*): 5
SET TERM ON;
PRO ^^time_stamp1. GV$SQL_PLAN_STATISTICS_ALL;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_GVsSQL_PLAN_STATISTICS_ALL.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQL_PLAN_STATISTICS_ALL WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID GV_$SQL_REDIRECTION');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQL_REDIRECTION ^^time_stamp1.');
-- select: GV$SQL_REDIRECTION by sql_id. count(*): 1
SET TERM ON;
PRO ^^time_stamp1. GV$SQL_REDIRECTION;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_GVsSQL_REDIRECTION.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQL_REDIRECTION WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: GV$SQL_REOPTIMIZATION_HINTS by sql_id. reason: COUNT(*) = 0
-- skip: GV$SQL_SHARD by sql_id. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID GV_$SQL_SHARED_CURSOR');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQL_SHARED_CURSOR ^^time_stamp1.');
-- select: GV$SQL_SHARED_CURSOR by sql_id. count(*): 1
SET TERM ON;
PRO ^^time_stamp1. GV$SQL_SHARED_CURSOR;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_GVsSQL_SHARED_CURSOR.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQL_SHARED_CURSOR WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: GV$SQL_SHARED_MEMORY by sql_id. reason: COUNT(*) = 0
-- skip: GV$SQL_TESTCASES by sql_id. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'SQL_ID GV_$SQL_WORKAREA');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQL_WORKAREA ^^time_stamp1.');
-- select: GV$SQL_WORKAREA by sql_id. count(*): 3
SET TERM ON;
PRO ^^time_stamp1. GV$SQL_WORKAREA;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_GVsSQL_WORKAREA.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQL_WORKAREA WHERE SQL_ID = '3zppxfr1zf4cs' AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: GV$SQL_WORKAREA_ACTIVE by sql_id. reason: COUNT(*) = 0
-- skip: GV$VPD_POLICY by sql_id. reason: COUNT(*) = 0
-- skip: WRH$_ACTIVE_SESSION_HISTORY by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRH$_ACTIVE_SESSION_HISTORY_BL by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRH$_SQLSTAT by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRH$_SQLSTAT_BL by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRH$_SQLTEXT by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRH$_SQL_BIND_METADATA by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRH$_SQL_PLAN by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRHS$_SQLTEXT by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRHS$_SQL_BIND_METADATA by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRHS$_SQL_PLAN by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRI$_ADV_SQLA_STMTS by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRI$_ADV_SQLA_TABLES by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRI$_ADV_SQLT_PLAN_HASH by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRI$_SQLSET_PLANS_TOCAP by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRI$_SQLSET_STATEMENTS by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRI$_SQLSET_WORKSPACE by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRI$_SQLTEXT_REFCOUNT by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRM$_COLORED_SQL by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRR$_CAPTURE_LONG_SQLTEXT by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRR$_CAPTURE_SCHEMA_INFO by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRR$_CAPTURE_SCHEMA_INFO_TMP by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRR$_CAPTURE_SQLTEXT by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRR$_CAPTURE_SQL_TMP by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRR$_REPLAY_DIVERGENCE by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRR$_REPLAY_DIV_SUMMARY by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRR$_REPLAY_SQL_MAP by sql_id. reason: ORA-00942: la tabla o vista no existe
-- skip: WRR$_REPLAY_SQL_TEXT by sql_id. reason: ORA-00942: la tabla o vista no existe
COL sql_text PRI;
COL sql_fulltext PRI;
CL BRE;
/*********************************************************************************/
HOS zip -m sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_csv sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_*.csv
HOS unzip -l sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_csv
HOS zip -m sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_3zppxfr1zf4cs_*.zip
HOS unzip -l sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx
/*********************************************************************************/
SET TERM ON;
PRO ###
PRO ### by exact signature
PRO ###
SET TERM OFF;
-- skip: DBA_SQL_PATCHES by exact signature. reason: COUNT(*) = 0
-- skip: DBA_SQL_PLAN_BASELINES by exact signature. reason: COUNT(*) = 0
-- skip: DBA_SQL_PROFILES by exact signature. reason: COUNT(*) = 0
-- skip: DBA_SQL_QUARANTINE by exact signature. reason: COUNT(*) = 0
-- skip: SQL$ by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQL$TEXT by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQL$TEXT_DATAPUMP by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQL$TEXT_DATAPUMP_TBL by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQL$_DATAPUMP by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQL$_DATAPUMP_TBL by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLLOG$ by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$ by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$AUXDATA by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$AUXDATA_DATAPUMP by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$AUXDATA_DATAPUMP_TBL by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$DATA by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$DATA_DATAPUMP by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$DATA_DATAPUMP_TBL by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$PLAN by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$PLAN_DATAPUMP by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$PLAN_DATAPUMP_TBL by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$_DATAPUMP by exact signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$_DATAPUMP_TBL by exact signature. reason: ORA-00942: la tabla o vista no existe
COL sql_text PRI;
COL sql_fulltext PRI;
CL BRE;
/*********************************************************************************/
SET TERM ON;
PRO ###
PRO ### by force signature
PRO ###
SET TERM OFF;
-- skip: DBA_HIST_ACTIVE_SESS_HISTORY by force signature. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'FORCE_MATCHING_SIGNATURE DBA_HIST_SQLSTAT');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_HIST_SQLSTAT ^^time_stamp1.');
-- select: DBA_HIST_SQLSTAT by force signature. count(*): 6
SET TERM ON;
PRO ^^time_stamp1. DBA_HIST_SQLSTAT;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_16675129290895924279_force_DBA_HIST_SQLSTAT.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_HIST_SQLSTAT WHERE FORCE_MATCHING_SIGNATURE = 16675129290895924279 AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_SQLSET_BINDS by force signature. reason: COUNT(*) = 0
-- skip: DBA_SQLSET_PLANS by force signature. reason: COUNT(*) = 0
-- skip: DBA_SQLSET_STATEMENTS by force signature. reason: COUNT(*) = 0
-- skip: DBA_SQL_PATCHES by force signature. reason: COUNT(*) = 0
-- skip: DBA_SQL_PLAN_BASELINES by force signature. reason: COUNT(*) = 0
-- skip: DBA_SQL_PROFILES by force signature. reason: COUNT(*) = 0
-- skip: DBA_SQL_QUARANTINE by force signature. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'FORCE_MATCHING_SIGNATURE GV_$ACTIVE_SESSION_HISTORY');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$ACTIVE_SESSION_HISTORY ^^time_stamp1.');
-- select: GV$ACTIVE_SESSION_HISTORY by force signature. count(*): 5
SET TERM ON;
PRO ^^time_stamp1. GV$ACTIVE_SESSION_HISTORY;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_16675129290895924279_force_GVsACTIVE_SESSION_HISTORY.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$ACTIVE_SESSION_HISTORY WHERE FORCE_MATCHING_SIGNATURE = 16675129290895924279 AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'FORCE_MATCHING_SIGNATURE GV_$ALL_ACTIVE_SESSION_HISTORY');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$ALL_ACTIVE_SESSION_HISTORY ^^time_stamp1.');
-- select: GV$ALL_ACTIVE_SESSION_HISTORY by force signature. count(*): 5
SET TERM ON;
PRO ^^time_stamp1. GV$ALL_ACTIVE_SESSION_HISTORY;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_16675129290895924279_force_GVsALL_ACTIVE_SESSION_HISTORY.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$ALL_ACTIVE_SESSION_HISTORY WHERE FORCE_MATCHING_SIGNATURE = 16675129290895924279 AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: GV$ALL_SQL_MONITOR by force signature. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'FORCE_MATCHING_SIGNATURE GV_$SQL');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQL ^^time_stamp1.');
-- select: GV$SQL by force signature. count(*): 6
SET TERM ON;
PRO ^^time_stamp1. GV$SQL;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_16675129290895924279_force_GVsSQL.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQL WHERE FORCE_MATCHING_SIGNATURE = 16675129290895924279 AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'FORCE_MATCHING_SIGNATURE GV_$SQLAREA');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQLAREA ^^time_stamp1.');
-- select: GV$SQLAREA by force signature. count(*): 6
SET TERM ON;
PRO ^^time_stamp1. GV$SQLAREA;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_16675129290895924279_force_GVsSQLAREA.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQLAREA WHERE FORCE_MATCHING_SIGNATURE = 16675129290895924279 AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'FORCE_MATCHING_SIGNATURE GV_$SQLAREA_PLAN_HASH');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQLAREA_PLAN_HASH ^^time_stamp1.');
-- select: GV$SQLAREA_PLAN_HASH by force signature. count(*): 6
SET TERM ON;
PRO ^^time_stamp1. GV$SQLAREA_PLAN_HASH;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_16675129290895924279_force_GVsSQLAREA_PLAN_HASH.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQLAREA_PLAN_HASH WHERE FORCE_MATCHING_SIGNATURE = 16675129290895924279 AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'FORCE_MATCHING_SIGNATURE GV_$SQLSTATS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQLSTATS ^^time_stamp1.');
-- select: GV$SQLSTATS by force signature. count(*): 7
SET TERM ON;
PRO ^^time_stamp1. GV$SQLSTATS;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_16675129290895924279_force_GVsSQLSTATS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQLSTATS WHERE FORCE_MATCHING_SIGNATURE = 16675129290895924279 AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'FORCE_MATCHING_SIGNATURE GV_$SQLSTATS_PLAN_HASH');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$SQLSTATS_PLAN_HASH ^^time_stamp1.');
-- select: GV$SQLSTATS_PLAN_HASH by force signature. count(*): 7
SET TERM ON;
PRO ^^time_stamp1. GV$SQLSTATS_PLAN_HASH;
SET TERM OFF;
-- output_type: C
COL sql_text NOPRI;
COL sql_fulltext NOPRI;
CL BRE;
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_16675129290895924279_force_GVsSQLSTATS_PLAN_HASH.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$SQLSTATS_PLAN_HASH WHERE FORCE_MATCHING_SIGNATURE = 16675129290895924279 AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: GV$SQL_MONITOR by force signature. reason: COUNT(*) = 0
-- skip: SQL$ by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQL$TEXT by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQL$TEXT_DATAPUMP by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQL$TEXT_DATAPUMP_TBL by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQL$_DATAPUMP by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQL$_DATAPUMP_TBL by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLLOG$ by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$ by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$AUXDATA by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$AUXDATA_DATAPUMP by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$AUXDATA_DATAPUMP_TBL by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$DATA by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$DATA_DATAPUMP by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$DATA_DATAPUMP_TBL by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$PLAN by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$PLAN_DATAPUMP by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$PLAN_DATAPUMP_TBL by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$_DATAPUMP by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: SQLOBJ$_DATAPUMP_TBL by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: WRH$_ACTIVE_SESSION_HISTORY by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: WRH$_ACTIVE_SESSION_HISTORY_BL by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: WRH$_SQLSTAT by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: WRH$_SQLSTAT_BL by force signature. reason: ORA-00942: la tabla o vista no existe
-- skip: WRI$_SQLSET_STATEMENTS by force signature. reason: ORA-00942: la tabla o vista no existe
COL sql_text PRI;
COL sql_fulltext PRI;
CL BRE;
/*********************************************************************************/
HOS zip -m sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_16675129290895924279_force_csv sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_16675129290895924279_force_*.csv
HOS unzip -l sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_16675129290895924279_force_csv
HOS zip -m sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_16675129290895924279_force_*.zip
HOS unzip -l sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx
/*********************************************************************************/
SET TERM ON;
PRO ###
PRO ### by table
PRO ###
SET TERM OFF;
-- skip: COLUMN_PRIVILEGES by table. reason: COUNT(*) = 0
-- skip: DBA_ADVISOR_SQLA_COLVOL by table. reason: COUNT(*) = 0
-- skip: DBA_ADVISOR_SQLA_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_ADVISOR_SQLA_TABVOL by table. reason: COUNT(*) = 0
-- skip: DBA_ADVISOR_SQLW_COLVOL by table. reason: COUNT(*) = 0
-- skip: DBA_ADVISOR_SQLW_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_ADVISOR_SQLW_TABVOL by table. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_ALL_TABLES');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_ALL_TABLES ^^time_stamp1.');
-- select: DBA_ALL_TABLES by table. count(*): 1
SET TERM ON;
PRO ^^time_stamp1. DBA_ALL_TABLES;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_ALL_TABLES.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_ALL_TABLES WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_ANALYTIC_VIEWS by table. reason: COUNT(*) = 0
-- skip: DBA_ANALYTIC_VIEWS_AE by table. reason: COUNT(*) = 0
-- skip: DBA_ATTRIBUTE_DIM_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_ATTRIBUTE_DIM_TABLES_AE by table. reason: COUNT(*) = 0
-- skip: DBA_AUTO_INDEX_IND_ACTIONS by table. reason: COUNT(*) = 0
-- skip: DBA_BLOCKCHAIN_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_CAPTURE_PREPARED_TABLES by table. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_CATALOG');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_CATALOG ^^time_stamp1.');
-- select: DBA_CATALOG by table. count(*): 1
SET TERM ON;
PRO ^^time_stamp1. DBA_CATALOG;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_CATALOG.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_CATALOG WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_CHANGE_NOTIFICATION_REGS by table. reason: COUNT(*) = 0
-- skip: DBA_CLUSTERING_DIMENSIONS by table. reason: COUNT(*) = 0
-- skip: DBA_CLUSTERING_JOINS by table. reason: COUNT(*) = 0
-- skip: DBA_CLUSTERING_KEYS by table. reason: COUNT(*) = 0
-- skip: DBA_CLUSTERING_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_CLU_COLUMNS by table. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_COL_COMMENTS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_COL_COMMENTS ^^time_stamp1.');
-- select: DBA_COL_COMMENTS by table. count(*): 5
SET TERM ON;
PRO ^^time_stamp1. DBA_COL_COMMENTS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_COL_COMMENTS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_COL_COMMENTS WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_COL_PENDING_STATS by table. reason: COUNT(*) = 0
-- skip: DBA_COL_PRIVS by table. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_CONSTRAINTS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_CONSTRAINTS ^^time_stamp1.');
-- select: DBA_CONSTRAINTS by table. count(*): 6
SET TERM ON;
PRO ^^time_stamp1. DBA_CONSTRAINTS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_CONSTRAINTS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_CONSTRAINTS WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_CONS_COLUMNS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_CONS_COLUMNS ^^time_stamp1.');
-- select: DBA_CONS_COLUMNS by table. count(*): 6
SET TERM ON;
PRO ^^time_stamp1. DBA_CONS_COLUMNS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_CONS_COLUMNS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_CONS_COLUMNS WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_CONS_OBJ_COLUMNS by table. reason: COUNT(*) = 0
-- skip: DBA_EDITIONING_VIEWS by table. reason: COUNT(*) = 0
-- skip: DBA_EDITIONING_VIEWS_AE by table. reason: COUNT(*) = 0
-- skip: DBA_ENCRYPTED_COLUMNS by table. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_EXPRESSION_STATISTICS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_EXPRESSION_STATISTICS ^^time_stamp1.');
-- select: DBA_EXPRESSION_STATISTICS by table. count(*): 24
SET TERM ON;
PRO ^^time_stamp1. DBA_EXPRESSION_STATISTICS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_EXPRESSION_STATISTICS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_EXPRESSION_STATISTICS WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_EXTERNAL_LOCATIONS by table. reason: COUNT(*) = 0
-- skip: DBA_EXTERNAL_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_FILE_GROUP_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_FLASHBACK_ARCHIVE_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_GG_AUTO_CDR_COLUMNS by table. reason: COUNT(*) = 0
-- skip: DBA_GG_AUTO_CDR_COLUMN_GROUPS by table. reason: COUNT(*) = 0
-- skip: DBA_GG_AUTO_CDR_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_GOLDENGATE_NOT_UNIQUE by table. reason: COUNT(*) = 0
-- skip: DBA_HIST_REPLICATION_TBL_STATS by table. reason: COUNT(*) = 0
-- skip: DBA_HIVE_COLUMNS by table. reason: COUNT(*) = 0
-- skip: DBA_HIVE_PART_KEY_COLUMNS by table. reason: COUNT(*) = 0
-- skip: DBA_HIVE_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_HIVE_TAB_PARTITIONS by table. reason: COUNT(*) = 0
-- skip: DBA_IMMUTABLE_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_IM_EXPRESSIONS by table. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_INDEXES');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_INDEXES ^^time_stamp1.');
-- select: DBA_INDEXES by table. count(*): 5
SET TERM ON;
PRO ^^time_stamp1. DBA_INDEXES;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_INDEXES.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_INDEXES WHERE (TABLE_OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_IND_COLUMNS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_IND_COLUMNS ^^time_stamp1.');
-- select: DBA_IND_COLUMNS by table. count(*): 8
SET TERM ON;
PRO ^^time_stamp1. DBA_IND_COLUMNS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_IND_COLUMNS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_IND_COLUMNS WHERE (TABLE_OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_IND_COLUMNS_V$ by table. reason: ORA-00942: la tabla o vista no existe
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_IND_EXPRESSIONS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_IND_EXPRESSIONS ^^time_stamp1.');
-- select: DBA_IND_EXPRESSIONS by table. count(*): 6
SET TERM ON;
PRO ^^time_stamp1. DBA_IND_EXPRESSIONS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_IND_EXPRESSIONS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_IND_EXPRESSIONS WHERE (TABLE_OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_IND_PENDING_STATS by table. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_IND_STATISTICS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_IND_STATISTICS ^^time_stamp1.');
-- select: DBA_IND_STATISTICS by table. count(*): 4
SET TERM ON;
PRO ^^time_stamp1. DBA_IND_STATISTICS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_IND_STATISTICS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_IND_STATISTICS WHERE (TABLE_OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_INTERNAL_TRIGGERS by table. reason: COUNT(*) = 0
-- skip: DBA_JOINGROUPS by table. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_JSON_COLUMNS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_JSON_COLUMNS ^^time_stamp1.');
-- select: DBA_JSON_COLUMNS by table. count(*): 1
SET TERM ON;
PRO ^^time_stamp1. DBA_JSON_COLUMNS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_JSON_COLUMNS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_JSON_COLUMNS WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_JSON_DATAGUIDES');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_JSON_DATAGUIDES ^^time_stamp1.');
-- select: DBA_JSON_DATAGUIDES by table. count(*): 1
SET TERM ON;
PRO ^^time_stamp1. DBA_JSON_DATAGUIDES;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_JSON_DATAGUIDES.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_JSON_DATAGUIDES WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_JSON_DATAGUIDE_FIELDS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_JSON_DATAGUIDE_FIELDS ^^time_stamp1.');
-- select: DBA_JSON_DATAGUIDE_FIELDS by table. count(*): 42
SET TERM ON;
PRO ^^time_stamp1. DBA_JSON_DATAGUIDE_FIELDS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_JSON_DATAGUIDE_FIELDS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_JSON_DATAGUIDE_FIELDS WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_LOBS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_LOBS ^^time_stamp1.');
-- select: DBA_LOBS by table. count(*): 1
SET TERM ON;
PRO ^^time_stamp1. DBA_LOBS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_LOBS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_LOBS WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_LOB_PARTITIONS by table. reason: COUNT(*) = 0
-- skip: DBA_LOB_SUBPARTITIONS by table. reason: COUNT(*) = 0
-- skip: DBA_LOB_TEMPLATES by table. reason: COUNT(*) = 0
-- skip: DBA_LOG_GROUPS by table. reason: COUNT(*) = 0
-- skip: DBA_LOG_GROUP_COLUMNS by table. reason: COUNT(*) = 0
-- skip: DBA_MINING_MODEL_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_NESTED_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_NESTED_TABLE_COLS by table. reason: COUNT(*) = 0
-- skip: DBA_OBJECT_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_OBJECT_USAGE by table. reason: COUNT(*) = 0
-- skip: DBA_OBJ_COLATTRS by table. reason: COUNT(*) = 0
-- skip: DBA_OLDIMAGE_COLUMNS by table. reason: COUNT(*) = 0
-- skip: DBA_PARALLEL_EXECUTE_TASKS by table. reason: COUNT(*) = 0
-- skip: DBA_PARTIAL_DROP_TABS by table. reason: COUNT(*) = 0
-- skip: DBA_PART_COL_STATISTICS by table. reason: COUNT(*) = 0
-- skip: DBA_PART_HISTOGRAMS by table. reason: COUNT(*) = 0
-- skip: DBA_PART_INDEXES by table. reason: COUNT(*) = 0
-- skip: DBA_PART_LOBS by table. reason: COUNT(*) = 0
-- skip: DBA_PART_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_PENDING_CONV_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_PRIVATE_TEMP_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_REFS by table. reason: COUNT(*) = 0
-- skip: DBA_ROLLING_UNSUPPORTED by table. reason: COUNT(*) = 0
-- skip: DBA_SECUREFILE_LOG_TABLES by table. reason: ORA-00942: la tabla o vista no existe
-- skip: DBA_SENSITIVE_DATA by table. reason: COUNT(*) = 0
-- skip: DBA_SENSITIVE_DATA_TBL by table. reason: ORA-00942: la tabla o vista no existe
-- skip: DBA_SNAPSHOTS by table. reason: COUNT(*) = 0
-- skip: DBA_SR_PARTN_OPS by table. reason: COUNT(*) = 0
-- skip: DBA_SR_STLOG_EXCEPTIONS by table. reason: COUNT(*) = 0
-- skip: DBA_SR_STLOG_STATS by table. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_STAT_EXTENSIONS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_STAT_EXTENSIONS ^^time_stamp1.');
-- select: DBA_STAT_EXTENSIONS by table. count(*): 6
SET TERM ON;
PRO ^^time_stamp1. DBA_STAT_EXTENSIONS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_STAT_EXTENSIONS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_STAT_EXTENSIONS WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_STREAMS_ADD_COLUMN by table. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_STREAMS_COLUMNS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_STREAMS_COLUMNS ^^time_stamp1.');
-- select: DBA_STREAMS_COLUMNS by table. count(*): 5
SET TERM ON;
PRO ^^time_stamp1. DBA_STREAMS_COLUMNS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_STREAMS_COLUMNS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_STREAMS_COLUMNS WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_STREAMS_DELETE_COLUMN by table. reason: COUNT(*) = 0
-- skip: DBA_STREAMS_KEEP_COLUMNS by table. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_STREAMS_NEWLY_SUPPORTED');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_STREAMS_NEWLY_SUPPORTED ^^time_stamp1.');
-- select: DBA_STREAMS_NEWLY_SUPPORTED by table. count(*): 1
SET TERM ON;
PRO ^^time_stamp1. DBA_STREAMS_NEWLY_SUPPORTED;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_STREAMS_NEWLY_SUPPORTED.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_STREAMS_NEWLY_SUPPORTED WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_STREAMS_RENAME_COLUMN by table. reason: COUNT(*) = 0
-- skip: DBA_STREAMS_TABLE_RULES by table. reason: COUNT(*) = 0
-- skip: DBA_STREAMS_TRANSFORMATIONS by table. reason: COUNT(*) = 0
-- skip: DBA_STREAMS_UNSUPPORTED by table. reason: COUNT(*) = 0
-- skip: DBA_SUBPARTITION_TEMPLATES by table. reason: COUNT(*) = 0
-- skip: DBA_SUBPART_COL_STATISTICS by table. reason: COUNT(*) = 0
-- skip: DBA_SUBPART_HISTOGRAMS by table. reason: COUNT(*) = 0
-- skip: DBA_SYNC_CAPTURE_PREPARED_TABS by table. reason: COUNT(*) = 0
-- skip: DBA_SYNC_CAPTURE_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_SYNONYMS by table. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_TABLES');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_TABLES ^^time_stamp1.');
-- select: DBA_TABLES by table. count(*): 1
SET TERM ON;
PRO ^^time_stamp1. DBA_TABLES;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_TABLES.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_TABLES WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_TAB_COLS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_TAB_COLS ^^time_stamp1.');
-- select: DBA_TAB_COLS by table. count(*): 11
SET TERM ON;
PRO ^^time_stamp1. DBA_TAB_COLS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_TAB_COLS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_TAB_COLS WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_TAB_COLS_V$ by table. reason: ORA-00942: la tabla o vista no existe
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_TAB_COLUMNS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_TAB_COLUMNS ^^time_stamp1.');
-- select: DBA_TAB_COLUMNS by table. count(*): 5
SET TERM ON;
PRO ^^time_stamp1. DBA_TAB_COLUMNS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_TAB_COLUMNS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_TAB_COLUMNS WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_TAB_COL_STATISTICS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_TAB_COL_STATISTICS ^^time_stamp1.');
-- select: DBA_TAB_COL_STATISTICS by table. count(*): 11
SET TERM ON;
PRO ^^time_stamp1. DBA_TAB_COL_STATISTICS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_TAB_COL_STATISTICS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_TAB_COL_STATISTICS WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_TAB_COMMENTS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_TAB_COMMENTS ^^time_stamp1.');
-- select: DBA_TAB_COMMENTS by table. count(*): 1
SET TERM ON;
PRO ^^time_stamp1. DBA_TAB_COMMENTS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_TAB_COMMENTS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_TAB_COMMENTS WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_TAB_HISTGRM_PENDING_STATS by table. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_TAB_HISTOGRAMS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_TAB_HISTOGRAMS ^^time_stamp1.');
-- select: DBA_TAB_HISTOGRAMS by table. count(*): 524
SET TERM ON;
PRO ^^time_stamp1. DBA_TAB_HISTOGRAMS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_TAB_HISTOGRAMS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_TAB_HISTOGRAMS WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_TAB_IDENTITY_COLS by table. reason: COUNT(*) = 0
-- skip: DBA_TAB_MODIFICATIONS by table. reason: COUNT(*) = 0
-- skip: DBA_TAB_PARTITIONS by table. reason: COUNT(*) = 0
-- skip: DBA_TAB_PENDING_STATS by table. reason: COUNT(*) = 0
-- skip: DBA_TAB_PRIVS by table. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_TAB_STATISTICS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_TAB_STATISTICS ^^time_stamp1.');
-- select: DBA_TAB_STATISTICS by table. count(*): 1
SET TERM ON;
PRO ^^time_stamp1. DBA_TAB_STATISTICS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_TAB_STATISTICS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_TAB_STATISTICS WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_TAB_STATS_HISTORY');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_TAB_STATS_HISTORY ^^time_stamp1.');
-- select: DBA_TAB_STATS_HISTORY by table. count(*): 7
SET TERM ON;
PRO ^^time_stamp1. DBA_TAB_STATS_HISTORY;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_TAB_STATS_HISTORY.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_TAB_STATS_HISTORY WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_TAB_STAT_PREFS by table. reason: COUNT(*) = 0
-- skip: DBA_TAB_SUBPARTITIONS by table. reason: COUNT(*) = 0
-- skip: DBA_TRIGGERS by table. reason: COUNT(*) = 0
-- skip: DBA_TRIGGERS_AE by table. reason: COUNT(*) = 0
-- skip: DBA_TRIGGER_COLS by table. reason: COUNT(*) = 0
-- skip: DBA_TSDP_IMPORT_ERRORS by table. reason: COUNT(*) = 0
-- skip: DBA_TSDP_POLICY_PROTECTION by table. reason: COUNT(*) = 0
-- skip: DBA_TSDP_POLICY_PROTECTION_TBL by table. reason: ORA-00942: la tabla o vista no existe
-- skip: DBA_TSTZ_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_TSTZ_TAB_COLS by table. reason: COUNT(*) = 0
-- skip: DBA_UNUSED_COL_TABS by table. reason: COUNT(*) = 0
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'TABLE DBA_UPDATABLE_COLUMNS');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_UPDATABLE_COLUMNS ^^time_stamp1.');
-- select: DBA_UPDATABLE_COLUMNS by table. count(*): 5
SET TERM ON;
PRO ^^time_stamp1. DBA_UPDATABLE_COLUMNS;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_DBA_UPDATABLE_COLUMNS.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_UPDATABLE_COLUMNS WHERE (OWNER, table_name) IN (('CVGT','MOVIMIENTOS_HISMO_VISTA_5')) AND ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
-- skip: DBA_XDS_ACL_REFRESH by table. reason: COUNT(*) = 0
-- skip: DBA_XDS_ACL_REFSTAT by table. reason: COUNT(*) = 0
-- skip: DBA_XDS_LATEST_ACL_REFSTAT by table. reason: COUNT(*) = 0
-- skip: DBA_XMLTYPE_COLS by table. reason: COUNT(*) = 0
-- skip: DBA_XML_INDEXES by table. reason: COUNT(*) = 0
-- skip: DBA_XML_NESTED_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_XML_OUT_OF_LINE_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_XML_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_XML_TAB_COLS by table. reason: COUNT(*) = 0
-- skip: DBA_XSTREAM_TRANSFORMATIONS by table. reason: COUNT(*) = 0
-- skip: DBA_XTERNAL_LOC_PARTITIONS by table. reason: COUNT(*) = 0
-- skip: DBA_XTERNAL_LOC_SUBPARTITIONS by table. reason: COUNT(*) = 0
-- skip: DBA_XTERNAL_PART_TABLES by table. reason: COUNT(*) = 0
-- skip: DBA_XTERNAL_TAB_PARTITIONS by table. reason: COUNT(*) = 0
-- skip: DBA_XTERNAL_TAB_SUBPARTITIONS by table. reason: COUNT(*) = 0
-- skip: DBA_XT_HIVE_TABLES_VALIDATION by table. reason: COUNT(*) = 0
-- skip: ROLE_TAB_PRIVS by table. reason: COUNT(*) = 0
-- skip: TABLE_PRIVILEGES by table. reason: COUNT(*) = 0
/*********************************************************************************/
HOS zip -m sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_csv sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_*.csv
HOS unzip -l sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_csv
HOS zip -m sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_table_*.zip
HOS unzip -l sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx
/*********************************************************************************/
SET TERM ON;
PRO ###
PRO ### by global
PRO ###
SET TERM OFF;
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'GLOBAL');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DBA_HIST_SNAPSHOT ^^time_stamp1.');
-- select: DBA_HIST_SNAPSHOT by global. count(*): 1204
SET TERM ON;
PRO ^^time_stamp1. DBA_HIST_SNAPSHOT;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_global_DBA_HIST_SNAPSHOT.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM DBA_HIST_SNAPSHOT WHERE ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS') time_stamp1 FROM DUAL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'sqldx.sql', action_name => 'GLOBAL');
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('GV_$PARAMETER2 ^^time_stamp1.');
-- select: GV$PARAMETER2 by global. count(*): 928
SET TERM ON;
PRO ^^time_stamp1. GV$PARAMETER2;
SET TERM OFF;
-- output_type: C
SPO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_global_GVsPARAMETER2.csv;
SET HEA ON PAGES 50000 LIN 32767 LONGC 4000 COLSEP ',';
SELECT * FROM GV$PARAMETER2 WHERE ROWNUM <= 10000;
SET HEA OFF PAGES 0 LIN 2000 LONGC 2000 COLSEP ' ';
SPO OFF;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(module_name => NULL, action_name => NULL);
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO(NULL);
/*********************************************************************************/
/*********************************************************************************/
HOS zip -m sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_global_csv sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_global_*.csv
HOS unzip -l sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_global_csv
HOS zip -m sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_global_*.zip
HOS unzip -l sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx
/*********************************************************************************/

SET TERM ON ECHO OFF FEED 6 VER ON SHOW OFF HEA ON LIN 80 NUM 10 NEWP 1 PAGES 14 LONG 80 LONGC 80 SQLC MIX TAB ON TRIMS OFF TI OFF TIMI OFF ARRAY 15 NUMF "" SQLP SQL> SUF sql BLO . RECSEP WR APPI OFF SERVEROUT OFF AUTOT OFF;
PRO
PRO sqlhc_20230707_1131_3zppxfr1zf4cs_8_sqldx_*.zip files have been created.
SET DEF ON;
